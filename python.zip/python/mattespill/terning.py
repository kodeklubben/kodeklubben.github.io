from random import randint

for i in range(25):
    print(randint(1, 6) + randint(1, 6))
